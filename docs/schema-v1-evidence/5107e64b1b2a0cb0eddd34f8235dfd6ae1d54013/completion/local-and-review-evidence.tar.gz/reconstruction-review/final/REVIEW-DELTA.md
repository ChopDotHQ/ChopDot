# Separate reconstruction delta review — REVISE

Candidate `f9392774637e1b154a439022d3fc7ce76388d6d7`, tree `db06cfc8b30088ee951b232747e9702674f3fadb`. Prior separately reviewed candidate `8a99f7c65306cdb0dd915d40c42405d7c48b6301`. Frozen authority remains `4ba456e6595330e4ca8e21366e0d827f17e10881`.

The repair removes global-occurrence control synthesis and adds a specific queued-request/delivery function witness relationship. I inspected the actual diff and re-executed the four same baseline/inventory/witness cases through the complete local schema workflow in disposable clones.

- Baseline: all 15 workflow shell commands pass; deterministic regeneration remains clean; 58/58 safety, 27/27 closure (23 semantic + 4 seal-only), 26 settlement assertions, 8 witness assertions.
- R01 invented object/law: unchanged seal-only rejection, explicitly disclosed bounded V1 limitation.
- R03a J17 wrong state: now independently rejected by `CONTROL-NOT-FOUND` and `WITNESS-CONTROL-PIECE-MISSING`, also seals. No reconstruction fallback is needed for the current valid baseline.
- R03b unrelated J13 phrases: now independently rejected by `WITNESS-PATH-OPERATION-RELATION`, also seals.
- **R03c (new adjacent mutant): clear the editable witness_types array and use the same unrelated phrases. Full regenerated workflow executes and only seals reject.** The new relation guard is conditional on the attacker-controlled SYSTEM_DERIVED label, so the family is incompletely repaired.
- R03d existing retry-event witness route: execution in progress at receipt creation; results stored separately under route-neighbor. Current code can dispatch to e.domain_event before the e.path-only invariant, despite request retry not witnessing initial queued/delivery progression.

Smallest remaining repair: require request.deliver's approved SYSTEM_DERIVED type and frozen queued-request/deliver-function relation by operation identity, outside/before the editable evidence-route dispatch. Retain normal witnesses/other operations and add type-demotion plus route-substitution regressions. Do not use e.path/evidence priority to bypass the required proof.

Four Python query examples in V1_USAGE_GUIDE.md executed successfully. The guide and README/generated wording now disclose source-grounding limits, finite coverage, trusted detector review, future-only/authority-only capabilities, and direct versus bounded downstream impact. No documentation blocker found.

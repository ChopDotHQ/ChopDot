import json, pathlib, subprocess, tempfile, shutil, os, yaml, time
SRC=pathlib.Path('/workspace/scratch/3e1932de6f4d/chopdot-final')
OUT=pathlib.Path(__file__).resolve().parent
BASE='f9392774637e1b154a439022d3fc7ce76388d6d7'
NODE='/root/.npm/_npx/52027bd8fc0022aa/node_modules/.bin'
ENV=dict(os.environ,PATH=NODE+':'+os.environ['PATH'])
results=[]
def run(cmd,cwd,log):
 t=time.time();r=subprocess.run(cmd,cwd=cwd,env=ENV,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log.write_text('$ '+(' '.join(cmd))+'\n'+r.stdout+'\nEXIT_CODE='+str(r.returncode)+'\n')
 return dict(command=cmd,exit_code=r.returncode,log=str(log.relative_to(OUT)),seconds=round(time.time()-t,3))
def git(p,*args):return subprocess.check_output(['git','-C',str(p),*args],text=True).strip()
def commit(p):
 subprocess.run(['git','-C',str(p),'add','product-schema'],check=True)
 subprocess.run(['git','-C',str(p),'-c','user.name=Independent Reconstruction Review','-c','user.email=review@example.invalid','-c','core.hooksPath=/dev/null','commit','--no-gpg-sign','--allow-empty','-qm','Disposable reconstructed mutant'],check=True)
with tempfile.TemporaryDirectory(prefix='chopdot-reconstruction-review-') as tmp:
 for cid in ['R03d-j13-retry-event']:
  d=OUT/cid;d.mkdir(exist_ok=True);p=pathlib.Path(tmp)/cid
  setup=run(['git','clone','--shared','--no-checkout',str(SRC),str(p)],OUT,d/'clone.log');assert setup['exit_code']==0
  setup=run(['git','checkout','--detach',BASE],p,d/'checkout.log');assert setup['exit_code']==0
  r=dict(case=cid,base=BASE,tree=git(p,'rev-parse','HEAD^{tree}'),provenance='reconstructed',commands=[])
  corep=p/'product-schema/semantic-core.json';recp=p/'product-schema/reconstruction-map-v1.json'
  if cid=='R01-invent-source-grounded':
   c=json.loads(corep.read_text());c['objects'].append(dict(id='invented.shadow',name='Invented Shadow',kind='canonical',identity=['id'],sources=['J12'],source_journeys=['12']));c['laws'].append(dict(id='LAW-INVENTED-SHADOW',name='Invented shadow law',applies_to=['invented.shadow'],rule='Invented semantics with a valid source key.',sources=['J12']));corep.write_text(json.dumps(c,indent=2)+'\n')
  elif cid=='R03a-j17-wrong-state':
   c=json.loads(recp.read_text());next(x for x in c['control_bindings'] if x['id']=='CTRL-J17-CONTRIBUTE')['state']='withdraw-review';recp.write_text(json.dumps(c,indent=2)+'\n')
  elif cid=='R03d-j13-retry-event':
   c=json.loads(recp.read_text());w=next(x for x in c['operation_witnesses'] if x['schema_ref']=='request.deliver');w['evidence']={'domain_event':'RequestDeliveryRetryRequested'};recp.write_text(json.dumps(c,indent=2)+'\n')
  (d/'mutation.patch').write_text(git(p,'diff')+'\n')
  if cid!='R00-baseline':commit(p)
  wf=yaml.safe_load((p/'.github/workflows/product-schema-v1.yml').read_text());chain=[s['run'] for s in wf['jobs']['schema']['steps'] if 'run' in s and not s['run'].startswith('git fetch')]
  # Exact required evidence commit exists in shared object store; validate file presence explicitly.
  r['prerequisite']=run(['git','cat-file','-e','8548313791e4ef7b436ee742cd18c1fa48d74eeb:prototypes/integrated-product-preview-v2/money-v1.js'],p,d/'prerequisite.log')
  r['regeneration']=[]
  for n,cmd in enumerate(c for c in chain if c.startswith('node product-schema/derive-')):
   r['regeneration'].append(run(['bash','-eo','pipefail','-c',cmd],p,d/f'generate-{n}.log'))
  r['regeneration_diff']=git(p,'diff','--name-only');(d/'regeneration.patch').write_text(git(p,'diff')+'\n')
  if cid!='R00-baseline':commit(p)
  for n,cmd in enumerate(chain):r['commands'].append(run(['bash','-eo','pipefail','-c',cmd],p,d/f'chain-{n:02d}.log'))
  cov=json.loads((p/'product-schema/generated/reconstruction-coverage.json').read_text());r['errors']=cov['errors'];r['post_diff']=git(p,'diff','--name-only')
  for f in ['reconstruction-coverage.json','adversarial-closure-coverage.json','mutation-coverage.json','blast-radius.json']:
   shutil.copyfile(p/'product-schema/generated'/f,d/f)
  seals={'AUTHORED-BLOB-DRIFT','AUTHORED-BLOB-UNDECLARED','FREEZE-SEAL-DRIFT'}
  r['semantic_error_ids']=sorted({e['id'] for e in r['errors']}-seals);r['seal_error_ids']=sorted({e['id'] for e in r['errors']}&seals)
  r['full_chain_pass']=all(x['exit_code']==0 for x in r['commands']+r['regeneration'])
  results.append(r);(OUT/'review-matrix-results.json').write_text(json.dumps(results,indent=2)+'\n');print(cid,r['semantic_error_ids'],r['seal_error_ids'],r['full_chain_pass'],flush=True)

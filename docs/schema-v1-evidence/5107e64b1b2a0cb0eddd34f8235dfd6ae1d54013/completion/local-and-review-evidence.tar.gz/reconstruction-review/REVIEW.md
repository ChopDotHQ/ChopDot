# Separate reconstruction review — REVISE

Reviewed candidate: `8a99f7c65306cdb0dd915d40c42405d7c48b6301`, tree `cc3ca2af38f1c340fe51ae33252a656c246b0669`.
Prior base: `bc7473c8eebd1511b9a92fe3c1e25e2670c29b46`, tree `a5d02c43d8665097269e556e38ae09016c60f887`.
Frozen product authority: `4ba456e6595330e4ca8e21366e0d827f17e10881`.
This reviewer is separate from the integrating writer and made no candidate/shared branch/lease changes. All execution used disposable clones. This is a scoped review, not approval to freeze or a claim of universally complete executable reconstruction.

## Findings and dispositions

- **REV-SCHEMA-WITNESS-RELATION-03 — REVISE, narrow verifier defect confirmed.** Moving `CTRL-J17-CONTRIBUTE` from `add-review` to existing `withdraw-review` synthesizes a false domain-operation control because the fallback checks state existence and label/target occurrence independently across the entire source file. Replacing `request.deliver` evidence with unrelated but sufficiently long `function rawSource(s)` and `function allowed(s)` phrases from its real frozen model is also accepted semantically. Both cases ran all required local workflow commands after regeneration; only `verify-reconstruction-closure.mjs` rejected, via authored-blob and closure seal drift. Thus neither is a full-chain escape, but both remain semantic witness gaps. Repair the state-local action tuple relation and the operation-specific frozen queue/deliver relation. Keep current good witnesses and unrelated controls passing.
- **REV-SCHEMA-SEMANTIC-GROUNDING-01 — CONFIRMED, retained bounded V1 limitation.** The shipped invented shadow object/law pair is counted as source-grounded solely because J12 exists. Independent full-chain execution confirms no semantic rejection and two seal layers rejecting. The exact V1 inventory is protected by unchanged reviewed seal constants; that is not proof of arbitrary object/law meaning. Do not promote source-key accounting to universal semantic verification. Explicitly retain this limitation and require independent source-grounded review for future inventory/authority changes; no blanket redesign is recommended for this completion.
- **REV-SCHEMA-TRUSTED-DETECTOR-BOUNDARY-02 — disposition: exact-version trusted-code review boundary.** Validator implementations and seal expectations are candidate-owned. No recursive self-hash can make those bytes independently trustworthy. Against the immutable prior base, the repair does not alter `stage-5-freeze-lib.mjs`, existing validation implementation, or any nine authored baseline bytes; seal constants are unchanged. Independent review of the exact detector diff, untouched frozen authority, and final tested SHA is the appropriate bounded control. This receipt does not authorize a future seal refresh and cannot clear unreviewed successor detector bytes.
- **SEC-SCHEMA-001 reconstruction effects — no new reconstruction loss found in reviewed repair.** Diff adds consumption checks, regression assertions, and two diagnostic changes; unchanged authored sources mean no product piece/route/operation authority alteration. Safety/security clearance is handled by the separate security reviewer.

## Executed evidence

`review-matrix.py` is reusable and writes only within its evidence directory and temporary clones. `review-matrix-results.json` records commands, exit codes and classifications; four case directories contain exact mutation patches, regenerated diffs, logs and generated detector records.

| Case | Full local chain | Semantic errors | Seal errors | Classification |
|---|---|---|---|---|
| R00-baseline | 15/15 commands passed | none | none | valid control PASS |
| R01-invent-source-grounded | all 15 executed; closure verifier failed | none | AUTHORED-BLOB-DRIFT, FREEZE-SEAL-DRIFT | seal-only rejection |
| R03a-j17-wrong-state | all 15 executed; closure verifier failed | none | AUTHORED-BLOB-DRIFT, FREEZE-SEAL-DRIFT | seal-only rejection |
| R03b-j13-unrelated-phrases | all 15 executed; closure verifier failed | none | AUTHORED-BLOB-DRIFT, FREEZE-SEAL-DRIFT | seal-only rejection |

Each case ran all four generators before the chain and again where the workflow calls them. Mutation authored bytes were committed in the disposable clone before generation, because the integrity detector reads HEAD blobs. Generated experimental outputs were committed solely for deterministic-output testing; trusted detectors, seal expectations, frozen authority remained unchanged. Post-chain diff was empty in every case. The clean baseline's first regeneration also had no tracked diff. Gate A evidence prerequisite was checked at exact object `8548313791e4ef7b436ee742cd18c1fa48d74eeb:prototypes/integrated-product-preview-v2/money-v1.js`; no new network fetch was needed in the shared object store. Node 22 was used. These are local execution results, not hosted Actions, Cypress or production tests.

The baseline re-executed shipped independent safety battery **58/58**, closure battery **27/27 = 23 semantic + 4 seal-only**, and settlement-consumption regressions **26**. The 58/27 batteries execute their shipped in-memory co-mutations; this receipt does not misstate them as 85 separate full-regeneration clones. The four narrow reviewer cases above are separate full-chain experiments. The 27 covers wrong task witnesses, wrong existing aliases, live-state supersession, C1 collapse, extra trigger reclassification and navigation/domain confusion; the executed closure verifier separately enforces extraction denominators, duplicate conflicts and bounded blast assertions. Seal-only cases remain executable/blob integrity probes (3) and invented inventory (1).

## Representative non-core reconstruction

`non-core-reconstruction.json` contains source snippets, exact source pins, controls, schema operations/laws, journey relationships and classifications for J09/J17/J25–J28. This was a read-only source-to-schema trace, not browser interaction or production reconstruction.

- J09 `remove-confirm` / Remove from group -> frozen `MemberRemovalRequested` -> `membership.remove`; payment-preference and settlement paths remain owner handoffs. Derived person/group views do not write a ledger.
- J17 `add-review` -> self-report `savings.contribute` and `withdraw-review` -> initiating `savings.withdraw`, governed by LAW-SAV-01/02. No optimistic confirmation or authority over another participant is created. The -03 alternate-state false witness is a demonstrated verifier gap, not a defect in the unchanged current correct binding.
- J25 Create backup -> `storage.create_backup`; Apply restore -> `storage.restore` / LAW-STORAGE-01. Frozen seed spec is stale, but frozen `review-v1/VISUAL_QA.md` explicitly binds approved candidate `94957bce…`, HTML SHA-256 `785fd02267b1e47e1bde8513a6c91373ee1ce8dd85b35812201f0af92c77ca3f`, and 71/71 reachability. No live storage/provider implementation inferred.
- J26 rename/archive, ownership transfer, leave and delete bind distinct operations; LAW-GROUP-01/02 preserves historical money and scoped authority. Group administration is not payment authority.
- J27 preference saves, session sign-out and account deletion bind separate operations; reversible preview, LAW-AUTH-01/LAW-PREF-01, ownership/open-money guards remain distinct. No global erasure claim.
- J28 Check same operation -> `recovery.reconcile`; Start replacement -> `recovery.safe_retry`; LAW-OP-01/02/03 keeps unknown outcomes on original identity and requires proven no effect before replacement. Navigation is not an execution result.

Blast graph code and baseline assertions distinguish direct dependencies from bounded downstream effects. Reached consumer operations are not assumed to execute. Tasks attach via their semantic operation, not every task in an affected journey. Extraction combines pinned mapping/model/dynamic/static sources, retaining duplicate evidence rather than inventing distinct behaviors.

## Retained limits and next action

Retain **667 authority-only PRODUCT_REQUIREMENT states**, **35 draft fields without semantic refs**, **59 duplicate evidence instances with zero conflicts**, and **21 construction-required states limited to J05/J06/J08**. Contract-only, future-only, draft, external-boundary, navigation and system-progression classifications are not universally executable product proofs. Source-key grounding is a bounded inventory-accounting mechanism, with invented additions caught by reviewed seals.

The completion owner should make the narrow -03 verifier/regression repair, rerun these same fresh mutations and valid control, then request this reviewer's exact successor delta review. Broader architecture changes or new product rules are unnecessary. No final clearance is issued for the reviewed candidate until -03 is resolved and final candidate bytes reviewed.

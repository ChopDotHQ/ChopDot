import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
const {validateSettlementConsumption:validate}=await import(pathToFileURL(root+'/product-schema/stage-5-safety-lib.mjs'));
const core=JSON.parse(readFileSync(root+'/product-schema/semantic-core.json'));
const graph=JSON.parse(readFileSync(root+'/product-schema/composition-graph.json'));
const results=[];
function run(id,change,expected){const g=structuredClone(graph);change(g);const errors=validate(core,g);assert.equal(expected?errors.some(e=>e.id===expected):errors.length===0,true,JSON.stringify({id,errors}));results.push({id,expected:expected||'ACCEPT',semantic_errors:errors});}
function effect(g){const c=structuredClone(g.contexts.find(c=>c.id==='ctx.settlement'));c.id='ctx.review_effect';c.name='Effect carrier';g.contexts.push(c);const j=g.journey_projections.find(j=>j.id==='12');j.entry_contexts_any=['ctx.group'];j.effect_contexts_required=[c.id];return c;}
run('SREV-CTRL-UNCHANGED',()=>{},null);
run('SREV-CTRL-EFFECT-CARRIER',effect,null);
run('SREV-EFFECT-MISSING-OP02',g=>{const c=effect(g);c.laws=c.laws.filter(x=>x!=='LAW-OP-02');},'SETTLEMENT-CONSUMER-LAW');
run('SREV-EFFECT-APPROXIMATE-AMOUNT',g=>{const c=effect(g);c.preserves=c.preserves.map(x=>x==='exact amount'?'approximate amount':x);},'SETTLEMENT-CONSUMER-PRESERVATION');
run('SREV-EFFECT-EMPTY',g=>{const c=effect(g);c.objects=[];c.laws=[];c.preserves=[];},'SETTLEMENT-CONSUMER-OBJECT');
run('SREV-CTRL-UNUSED-PAYMENT-CONTEXT',g=>{g.contexts.push({id:'ctx.unused_review',objects:['payment.intent'],laws:[],preserves:[]});},null);
run('SREV-HISTORY-RECORD-CARRIER',g=>{const c=structuredClone(g.contexts.find(c=>c.id==='ctx.settlement'));c.id='ctx.review_history';c.name='History handoff';c.laws=c.laws.filter(x=>x!=='LAW-PAY-02');g.contexts.push(c);g.journey_projections.find(j=>j.id==='15').entry_contexts_any=[c.id];},'SETTLEMENT-CONSUMER-LAW');
run('SREV-PREPARE-NO-HANDOFF',g=>{g.journey_projections.find(j=>j.id==='11').emits_contexts=['ctx.group'];},'SETTLEMENT-CONSUMER-HANDOFF');
console.log(JSON.stringify({scope:'semantic validator unit-level only; not full-chain mutant execution',results},null,2));

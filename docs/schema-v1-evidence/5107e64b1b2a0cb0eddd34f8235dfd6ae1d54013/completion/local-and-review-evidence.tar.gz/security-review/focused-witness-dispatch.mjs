import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
const root=process.argv[2];
const {validateOperationWitnesses:validate}=await import(pathToFileURL(root+'/product-schema/stage-5-validation-lib.mjs'));
const read=n=>JSON.parse(readFileSync(root+'/product-schema/'+n));
const core=read('semantic-core.json'),graph=read('composition-graph.json'),rec=read('reconstruction-map-v1.json'),pieces=read('generated/reconstruction-pieces.json').pieces,bindings=read('domain-event-bindings-v1.json'),tasks=read('task-paths-v1.json');
const evidence=p=>execFileSync('git',['show','4ba456e6595330e4ca8e21366e0d827f17e10881:'+p],{cwd:root,encoding:'utf8'});
const run=r=>validate(core,graph,r,pieces,bindings,tasks,evidence);
assert.deepEqual(run(rec),[]);
const results=[{id:'CTRL-WITNESS-UNCHANGED',result:'ACCEPT'}];
for(const [key,value] of Object.entries({control_binding_id:'CTRL-J17-CONTRIBUTE',domain_event:'RequestDeliveryRetryRequested',task_ref:'TASK-J05-COMMON-EQUAL',schema_source:'J13'})){
 for(const val of [value,null]){
  const r=structuredClone(rec),w=r.operation_witnesses.find(w=>w.schema_ref==='request.deliver');w.evidence[key]=val;
  const errors=run(r);assert.ok(errors.some(e=>e.id==='WITNESS-PATH-OPERATION-RELATION'&&e.schema_ref==='request.deliver'));
  results.push({id:'WITNESS-DISPATCH-'+key+'-'+(val===null?'NULL':'VALUE'),semantic_errors:errors});
 }
}
console.log(JSON.stringify({scope:'Unit-level dispatcher diversion probes; not full-chain mutants',results},null,2));

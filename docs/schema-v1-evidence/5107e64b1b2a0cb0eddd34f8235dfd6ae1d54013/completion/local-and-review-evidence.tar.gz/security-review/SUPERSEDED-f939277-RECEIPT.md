> SUPERSEDED / HOLD: separate reconstruction reviewer subsequently identified an editable witness-type bypass of the new request.deliver path relation. This f939277 receipt is no longer final clearance. Await corrected exact-version delta review.

# Product Schema V1 — Security — CLEAR_FOR_FREEZE_RECOMMENDATION

Exact final candidate: **`f9392774637e1b154a439022d3fc7ce76388d6d7`**

Exact tree: **`db06cfc8b30088ee951b232747e9702674f3fadb`**

Frozen product authority: `4ba456e6595330e4ca8e21366e0d827f17e10881`.

This final receipt supersedes the candidate binding in `RECEIPT.md` after a separate read-only delta review from previously reviewed `8a99f7c65306cdb0dd915d40c42405d7c48b6301`. It incorporates that receipt's recorded scope, historical experiment provenance and limitations without claiming those prior full-chain mutants were rerun on the final SHA. This agent did not implement either repair or edit the candidate.

## Actual delta reviewed

Inspected all eight changed files and confirmed clean exact SHA/tree. The delta removes source-wide control fallback, so only a parsed state-local label/target tuple can support a bound control. The sole raw-path SYSTEM_DERIVED witness (`request.deliver`) now requires the declared J13 model, queued-request evidence inside `accept`, and `deliver` evidence with the request lookup and delivery update. The eight assertions include two unchanged controls plus two misplaced-control and four unrelated/partial/swapped phrase attacks. Existing settlement-consumption logic remains byte-identical.

The witness relationship fix is narrowly tied to the current immutable source representation. It does not invent behavior or claim general code analysis; a future authority/source implementation change requires reviewed updating of that witness contract. The removal of the permissive control fallback is justified because the unchanged extracted inventory and current witnesses still pass. No security regression or new blocker was demonstrated.

The usage guide and revised README/generated wording accurately separate machine checks, authority accounting, finite coverage, trusted-detector review, seal-only defenses and human approval. No runtime, Gate B, product source, semantic schema or seal constants changed in this delta.

## Executed at the final SHA

`final-delta-checks.json` and `final-delta-0.log` through `final-delta-3.log` contain commands, output and exit codes. Node 22 execution:

- Reconstruction closure: PASS; 92 source pins, 141 events, 4,418 pieces, 49 operations and 21 scoped construction states.
- Safety mutation battery: 58/58.
- Adversarial closure battery: 27/27, retaining **23 semantic and four seal-only** outcomes.
- Settlement regressions: 26/26.
- Witness-relation regressions: 8/8.
- Mechanical mutation verification: PASS, including all seven safety domains.
- Separate eight-case consumer-selector probes: PASS, preserving effect-time/unused-context controls and specific rejection cases.
- Git diff assertion: original product-authority working-tree paths, semantic core, composition graph, reconstruction map, frozen baseline, Gate B oracle and the safety/freeze detector files are unchanged from the separately reviewed repair candidate.

These final battery counts are in-memory detector mutation executions. The earlier five historical full-chain security attacks and unchanged control remain individually bound to `8a99f7c` in `full-chain/results.json`; their concrete behavior is preserved as prior evidence with this actual delta review, not silently relabeled as final-SHA runs. The completion owner separately owns the complete final schema chain, final 25-case SEC matrix and hosted run evidence.

## Findings and acceptance boundary

- **SEC-SCHEMA-001:** resolved in the reviewed semantic repair; consumer contract implementation unchanged and final assertions pass.
- **REV-SCHEMA-WITNESS-RELATION-03:** reviewed fix introduces precise rejection and retains valid controls; no security objection. The separate reconstruction reviewer owns its final full-chain finding disposition.
- **TEST-SUPPORT-001:** reusable prior execution artifacts assessed and additional historical safety full-chain support delivered. It is an evidence obligation, not an independent new product rule.
- No additional blocking security finding was demonstrated.

Retained limitations from the first receipt remain: immutable seals supplement semantics; four closure cases remain seal-only; finite tests and source membership are not universal entailment or complete executable reconstruction. This clearance is a role-specific recommendation for these exact bytes, not a freeze/tag/merge authorization. Actual final-SHA hosted checks and explicit human exact-version approval remain the completion owner's required acceptance steps.

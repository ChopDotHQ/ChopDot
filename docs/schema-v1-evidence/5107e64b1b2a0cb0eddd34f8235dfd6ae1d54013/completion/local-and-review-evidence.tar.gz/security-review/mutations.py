"""Historical safety cases reconstructed directly from shipped fixed battery functions."""
import json

def cases():
    return [dict(id='CTRL-BASE',kind='valid_control',action='none')]+[dict(id=x,kind='attack',action=x) for x in ['SREV-MONEY-CROSS-PARTITION','SREV-IDENTITY-LINK-REWRITE','SREV-WALLET-SIGNING-WIDEN','SREV-RETRY-WITHOUT-NO-EFFECT','SREV-PAYER-RECEIPT']]

def apply(repo,case):
    a=case['action']
    if a=='none':return
    p=repo/'product-schema/semantic-core.json';r=repo/'product-schema/reconstruction-map-v1.json';core=json.loads(p.read_text());rec=json.loads(r.read_text())
    def op(i):return next(x for x in core['operations'] if x['id']==i)
    def law(i):return next(x for x in core['laws'] if x['id']==i)
    sync=None
    if a=='SREV-MONEY-CROSS-PARTITION':
        sync=law('LAW-MONEY-01');sync['constraint']['cross_partition_combine']=True
    elif a=='SREV-IDENTITY-LINK-REWRITE':op('participant.link_account')['rules'][0]='Rewrite participant_id and historical references.'
    elif a=='SREV-WALLET-SIGNING-WIDEN':op('wallet.execute_action')['rules'].append('Wallet may alter amount and recipient at signing.')
    elif a=='SREV-RETRY-WITHOUT-NO-EFFECT':
        sync=law('LAW-OP-02');sync['constraint']['replacement_retry_requires_proven_no_effect']=False
    elif a=='SREV-PAYER-RECEIPT':op('settlement.confirm_receipt')['rules'].append('Payer may confirm receipt for the receiver.')
    else:raise ValueError(a)
    if sync:
        for x in rec['safety_contracts']:
            if x['schema_ref']==sync['id']:x['expected']={'applies_to':sync.get('applies_to',[]),'constraint':sync.get('constraint')}
        r.write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
    p.write_text(json.dumps(core,indent=2,ensure_ascii=False)+'\n')

# Product Schema V1 — separate Security review

Verdict: **CLEAR_FOR_FREEZE_RECOMMENDATION within the tested security scope**, bound only to candidate `8a99f7c65306cdb0dd915d40c42405d7c48b6301`, tree `cc3ca2af38f1c340fe51ae33252a656c246b0669`. This is an independent read-only review by the separate security-review agent, not implementation-owner self-review, a hosted-CI receipt, or human freeze approval. Later bytes require a delta review.

## Scope and provenance

Reviewed actual five-file diff against `bc7473c8eebd1511b9a92fe3c1e25e2670c29b46`, the actual safety and closure validators, regression assertions, current workflow, issue #50 body and current comments. Independently verified eight supplied source snapshots byte-for-byte against their immutable Git objects: frozen J11/J12/J15/J28, payment compatibility, storage/replay and both approved expense-lock decisions. Product authority remains `4ba456e6595330e4ca8e21366e0d827f17e10881`.

No edits to the candidate, coordination, lease, authority, seal constants or trusted implementation were made. All experimental commits were confined to automatically deleted temporary clones. The review scripts and logs are under this evidence directory.

## SEC-SCHEMA-001 assessment

The fix derives obligations from actual payment-intent owner/change operations, owning/participating journey references and payment-bearing context use. It separately follows payment-record carriers. It checks entry, ambient, effect and emitted contexts; completion without an effect carrier must have valid carriers on every entry alternative, and preparation must emit a carrier. Missing objects cannot evade checking simply by renaming the context or removing all payment objects from completion entry. Generic recovery, wallet and expense guard contexts are not newly required to carry the full payment contract. The obligations match the current approved normalization of the frozen exact-payment/identity/recovery contract; no new product rule was introduced.

The seven preservation strings are a fixed existing schema vocabulary, not arbitrary natural-language equivalence. This patch does not prove every sentence of J12 or any future operation semantics. Trusted verifier edits remain subject to review. Those are retained limits, not grounds to describe the demonstrated fix as ineffective.

The supplied 25-case-per-phase archive was inspected independently: baseline 1 semantic attack rejection and 20 seal-only attack rejections; repair 21 semantic attack rejections; both phases zero full-chain attack escapes and four semantically accepted controls. All fifteen workflow shell commands are recorded for every archived case. This is assessment of the prior evidence, not a claim this reviewer recreated those 50 experiments. The completion owner is rerunning the SEC matrix for the final version.

## Newly executed evidence

- `executed-checks.json` and individual command logs: actual Node 22 execution of reconstruction closure, mechanical mutations and hardening mutation battery at this candidate. Results: 58/58 safety, 27/27 adversarial closure (23 semantic, four seal-only), 26 settlement assertions, 32 hardening mutations. These are in-memory mutation batteries, not 117 independent full-workflow mutants.
- `focused-consumers.mjs` / `.log`: eight added unit-level selector checks. Unchanged, equivalent effect-time carrier and unused-context controls accepted; missing effect-time OP-02, approximate amount, empty effect carrier, history carrier without PAY-02 and preparation without a handoff rejected with the expected semantic IDs. These are unit probes, not full-chain mutants.
- `full-chain/`: fresh detached baseline plus five reconstructed historical safety cases. All four generators and all fifteen workflow shell commands actually ran per case, continuing after rejection to collect downstream evidence. Every generator exited zero. Every deterministic-output block passed; unchanged baseline had no unexplained regeneration diff. Authored mutant files were committed before regeneration because current seals inspect HEAD; only generated mutant diagnostics were then pinned. No seal constants were changed.

| Full-chain case | Semantic detector | Additional protection | Full chain |
| --- | --- | --- | --- |
| CTRL-BASE | No errors | No errors | PASS |
| SREV-MONEY-CROSS-PARTITION | MONEY-LAW | Authored blob + freeze seal | REJECT |
| SREV-IDENTITY-LINK-REWRITE | CRITICAL-OPERATION-DRIFT | Authored blob + freeze seal | REJECT |
| SREV-WALLET-SIGNING-WIDEN | CRITICAL-OPERATION-DRIFT | Authored blob + freeze seal | REJECT |
| SREV-RETRY-WITHOUT-NO-EFFECT | RECOVERY-RETRY | Authored blob + freeze seal | REJECT |
| SREV-PAYER-RECEIPT | CRITICAL-OPERATION-DRIFT | Authored blob + freeze seal | REJECT |

The money and recovery cases co-mutated the editable old safety expectations just as the shipped historical battery does. No unrelated early-stage route or ownership error blocked a fair test: all commands preceding reconstruction closure passed. Rejected command internals can stop at their first assertion; later assertions inside that command are not represented as executed. The runner's `phase: baseline` means no repair overlay on the already repaired candidate specified by `base_sha`, not the old bc7473 baseline.

## Mandatory historical security dispositions

The executable 58/27 batteries were rerun and their actual definitions inspected. They cover sent writes receipt, dropped/empty PAY-02 and extra equivalence, payer receipt, untagged force-close, invented sent-implies-received law, participant rewrite, wallet scope widening, PositionScope loss/empty applicability/group authorization, extra settlement context, navigation mutation and recovery governor cases. Selected money/identity/authority/recovery cases also received full-chain mutation runs above. The 32-case hardening battery executed approved expense guard, eligibility, partial remainder and related oracle checks.

The four existing seal-only classes remain explicitly seal-only: hardening executable blob drift, Gate B oracle blob drift, task contract blob drift, and invented source-grounded object/law. No independent semantic proof is claimed for them; critical operation comparisons are reviewed fixed authority-derived invariants, not arbitrary future semantic equivalence checking. The trusted-code boundary excludes modification of the verifier while attacking data. This review does not turn those disclosed defenses into semantic-completeness claims.

No additional blocking security finding was demonstrated. SEC-SCHEMA-001 is resolved on this exact reviewed candidate. TEST-SUPPORT-001's missing execution evidence has been supplied by the reusable prior harness and the completed matrix, subject to final-version evidence reconciliation by the completion owner. Reconstruction-specific acceptance is owned by the separate reconstruction reviewer.

## Reproduction and remaining acceptance

With Git, Python 3/PyYAML, Node 22 on PATH, and readable repository history:

```sh
python3 runner.py --repo /path/to/ChopDot --out /tmp/security-review-NEW
node focused-consumers.mjs /path/to/ChopDot
```

The output directory must be new. `runner.py` is adapted from the supplied reusable harness; `mutations.py` defines the stable reconstructed historical cases. It leaves the supplied checkout unchanged and automatically cleans its temporary clones. The fixed SHA/tree is embedded to prevent silent evidence transfer.

Remaining acceptance belongs to the completion owner: inspect this receipt alongside the separate reconstruction review, bind review deltas to any final documentation/tooling commit, collect actual five-workflow hosted results for that exact SHA, and request the user's exact-version freeze approval once. This review neither ran hosted Actions nor grants that approval.

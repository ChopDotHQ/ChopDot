"""Serve the unchanged review package on this computer using Python 3 only."""
import argparse
import functools
import http.server
import pathlib
import urllib.parse

root = pathlib.Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--port', type=int, default=8765)
args = parser.parse_args()

class ReviewHandler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.js': 'text/javascript', '.mjs': 'text/javascript'}

    def do_GET(self):
        if urllib.parse.urlsplit(self.path).path == '/favicon.ico':
            self.send_response(204)
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            return
        super().do_GET()

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

server = http.server.ThreadingHTTPServer(
    ('127.0.0.1', args.port), functools.partial(ReviewHandler, directory=str(root)))
print('Local review URL on this computer:')
print(f'http://127.0.0.1:{args.port}/prototypes/integrated-product-preview-v2/index.html', flush=True)
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
